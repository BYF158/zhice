<template>
  <div class="app-container">
  <div class="score-wrapper">
    <el-card class="score-card" shadow="hover">
      <h2>原型人格得分结果</h2>
      <div class="score-grid">
        <!-- 左列 -->
        <el-table :data="leftScores" stripe border :show-header="false" class="score-table">
          <el-table-column prop="name" label="原型"></el-table-column>
          <el-table-column prop="score" label="得分" width="120"></el-table-column>
        </el-table>

        <!-- 右列 -->
        <el-table :data="rightScores" stripe border :show-header="false" class="score-table">
          <el-table-column prop="name" label="原型"></el-table-column>
          <el-table-column prop="score" label="得分" width="120"></el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
  <!-- 返回首页按钮 -->
  <el-button type="primary" @click="goToHome" class="back-home-button">返回首页</el-button>
</div>
</template>


<script>
import { listPost, getPost, delPost } from "@/api/system/post"
import {getPersonalityScores} from "@/api/questions/topic"

export default {
  name: "Topic",
  dicts: ['sys_normal_disable'],
  data() {
    return {
      // 结果列表
      scores: [],
      recordId: null,
      userId: null,
      total: 0,
      // 结果表格数据
      postList: [],
      // 加载状态
      loading: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        userName: undefined,

      },
    }
  },
  computed: {
    sortedScores() {
      return this.scores.slice().sort((a, b) => b.score - a.score);
    },
    leftScores() {
      return this.sortedScores.slice(0, 6);
    },
    rightScores() {
      return this.sortedScores.slice(6, 12);
    }
  },

  created() {
    // 从路由查询参数中获取recordId和userId
    // this.recordId = this.$route.query.recordId;
    this.recordId = parseInt(localStorage.getItem("recordId"));
    this.userId = this.$route.query.userId;
    console.log("打印record：",this.recordId,this.userId)
    // 如果recordId存在，则加载评分数据
    if (this.recordId) {
      this.getPersonalityScores();
    }
  },
  methods: {
    /** 获取人格评分数据 */
    getPersonalityScores() {
      // 调用API获取评分数据
      this.loading = true;

      // 使用新定义的API方法
      getPersonalityScores(this.recordId, this.userId).then(response => {
        // 假设返回的数据结构为 { scores: [...] }
        console.log("打印评分数据：",response.data.scores)
        if (response && response.data.scores) {
          this.scores = response.data.scores;
        } else {
          this.$message.error('未能获取到评分数据');
        }

        this.loading = false;
      }).catch(() => {
        this.$message.error('获取评分数据失败');
        this.loading = false;
      });
    },
    /** 查询列表 */
    getList() {
      this.loading = true
      listPost(this.queryParams).then(response => {
        this.postList = response.rows
        this.total = response.total
        this.loading = false
      })
    },
    // 返回首页方法
    goToHome() {
      this.$router.push({ path: '/' });
    }
  }
}
</script>

<style scoped>
.score-wrapper {
  padding: 20px;
}
.score-card {
  padding: 20px;
}
h2 {
  margin-bottom: 20px;
  text-align: center;
}
.score-grid {
  display: flex;
  justify-content: space-around;
  gap: 20px;
}
.score-table {
  width: 45%;
}
.back-home-button {
  display: block;
  margin: 20px auto;
  text-align: center;
}
</style>
